console.log("entrada");
// validación 
$(document).ready(function () {
    $("#registro").val({
        debug: false,
        relues: {
            name: {
                required: true,
                minlength: 6,
            },
            email: {
                required: true,
                email: true,
            },
            password: {
                required: true,
                number: true,
                minlength: 8,
                maxlength: 20,
            },
            repeatpassword: {
                equalTo: "#password"
            }
        },
        messages: {
            name: {
                required: "Nombre obligatorio",
                minlength: "El nombre debe contener minimo 6 caracteres",
            },
            email: {
                required: "Digite su correo",
                email: "",
            },
            password: {
                required: "Digite su contraseña",
                minlength: "Debe contener minimo 8 caracteres",
                maxlength: "Debe contener maximo 20 caracteres",
            },
            repeatpassword: {
                minlength: "Debe contener minimo 8 caracteres",
                maxlength: "Debe contener maximo 20 caracteres",
                equalTo: "Debe coincidir con la contraseña"
            },
            errorElement: "div"
        },

    });
});

//Funcion registro

function registrarse(event) {
    event.preventDefault();
	console.log(event);
	
    let datos = {
        name: $("name").val(),
        email: $("email").val(),
        password: $("password").val(),
        //repeatpassword: $("repeatpassword").val(),
    };
    let datosPeticion = JSON.stringify(datos);

    $.ajax({
        url: "http://localhost:8080/api/user/new",
        data: datosPeticion,
        type: "POST",
        contentType: "application/JSON",

        success:function(respuesta){
            $("#message").show(1000);
            $("#message").html("Registro ingresado correctamente");
            $("#message").hide("1000");
			//console.log(respuesta);
            //estadoInicial();
        },
        error: function (xhr,status){
            $("#message").show(1000);
            $("#message").html("Error peticion Post" + status);
        }
      
    });

}

